package Domasno1;
//Trajche Smilevski INKI591
public class HelloWorld {
public static void main(String[] args)
{
	System.out.println("Hello World OOP FIKT");
}
}
